import java.lang.reflect.Array;
public class Main {
    public static void main(String[] args) {
        Musica papai_me_empresta = new Musica ("papai me empresta o carro", "Rita Lee", "pop-rock");
        Musica mania_de_voce = new Musica ("Mania de voce", "Rita Lee", "pop-rock");
        Musica tudo_vira_bosta = new Musica ("Tudo vira bosta", "Rita Lee", "pop-rock");

        Artista Rita_Lee = new Artista ("Rita Lee", "pop-rock");
        Artista Gabriel_o_Pensador = new Artista("Gabriel o pensador", "rap");
        Artista Raul_seixas = new Artista("Raul Seixas","Rock Br");

        Genero Pop_Rock = new Genero("pop-rock", "musicas com a mistura perfeita entre o melhor do pop e do rock brasileiro", "Rita Lee");
        Genero Rap = new Genero("Rap", "musicas de rap", "Gabriel o Pensador");
        Genero Rock_Br = new Genero("Rock Br", "musicas com o melhor do rock brasileiro", "Raul Seixas");

        tudo_vira_bosta.ListarMusicas();
        papai_me_empresta.ListarMusicas();
        mania_de_voce.ListarMusicas();

        Rita_Lee.ListarAristas();
        Gabriel_o_Pensador.ListarAristas();
        Raul_seixas.ListarAristas();

        Pop_Rock.ListarGeneros();
        Rap.ListarGeneros();
        Rock_Br.ListarGeneros();
    }
}