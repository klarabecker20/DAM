public class departamento {
    private String nome;
    private String local;

    public departamento(String nome, String local){
        this.nome = nome;
        this.local = local;
    }

    public String getNome(){
        return nome;
    }
}
