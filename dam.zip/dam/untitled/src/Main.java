import java.lang.reflect.Array;
public class Main {
    public static void main(String[] args) {
        Musica musica1 = new Musica ("papai me empresta o carro", "Rita Lee", "pop-rock");
        Musica musica2 = new Musica ("Mania de voce", "Rita Lee", "pop-rock");
        Musica musica3 = new Musica ("Tudo vira bosta", "Rita Lee", "pop-rock");

        Artista artista1 = new Artista ("Rita Lee", "pop-rock");
        Artista artista2 = new Artista("Gabriel o pensador", "rap");
        Artista artista3 = new Artista("Raul Seixas","Rock Br");

        Genero genero1 = new Genero("pop-rock", "musicas com a mistura perfeita entre o melhor do pop e do rock brasileiro", "Rita Lee");
        Genero genero2 = new Genero("Rap", "musicas de rap", "Gabriel o Pensador");
        Genero genero3 = new Genero("Rock Br", "musicas com o melhor do rock brasileiro", "Raul Seixas");

        musica3.ListarMusicas();
        musica1.ListarMusicas();
        musica2.ListarMusicas();

        artista1.ListarAristas();
        artista2.ListarAristas();
        artista3.ListarAristas();

        genero1.ListarGeneros();
        genero2.ListarGeneros();
        genero3.ListarGeneros();

        Usuario user = new Usuario("Claudo");

        user.ouvirMusica(musica2.getNome());

        Playlist p1 = new Playlist("Rita");

        p1.TocarMusica(musica1.getNome(), musica2.getNome(), musica3.getNome());
    }
}